    //loading all the music files
    var MusicLoad = function()
    {
        ballXPaddle = new Howl
        (
            {
                urls: ["sounds/Ball_Player.wav"],
                loop: false,
                buffer: false,
                volume: 0.5
            } 
        );
        ballXBrick = new Howl
        (
            {
                urls: ["sounds/Brick Break.wav"],
                loop: false,
                buffer: false,
                volume: 0.5
            } 
        );
        gameMusic = new Howl
        (
            {
                urls: ["sounds/Game Music.mp3"],
                loop: false,
                buffer: true,
                volume: 0.5
            } 
        );
        gameOver = new Howl
        (
            {
                urls: ["sounds/Game over.wav"],
                loop: false,
                buffer: false,
                volume: 0.5
            } 
        );
    }