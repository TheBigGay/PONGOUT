var spawnBrick = function(pX, pY, src)
{
    var brick = 
    {
        x:pX,
        y:pY,
        width:20,
        height:100
    }
    brick.image = document.createElement("img");
    brick.image.src = src;
    return brick;
}

var BrickCollisions = function()
{
    //variables for ball x brick collisions
    var ballCollider = RectangularCollider(ball1.x, ball1.y, ball1.width, ball1.height);
    var ballCollider2 = RectangularCollider(ball2.x, ball2.y, ball2.width, ball2.height);
    
    //This just creates the collisions for the bricks with the balls
    //When it detects a collision it plays a sound changes the direction of the ball and then deletes the brick in the array that got hit
    //Each brickcollider(number) it has detections for each ball, and since each ball is dedicated to a player, the 'player1Hit' variable is set to true to add to the score elsewhere
    for(var i = 0; i < bricks.length; i++)
    {     
        //var targets specific array. BrickCollider is for 1st array and so on
        var brickCollider = RectangularCollider(bricks[i].x - 5, bricks[i].y - 5, bricks[i].width + 10, bricks[i].height + 10);
        if(brickCollider.CheckCollision(ballCollider))
        {
            player1Hit = true; //for score
            ballXBrick.play(); //play sound
            ball1.dirX *= -1 ; //change direction
            ball1.x += ball1.dirX * (ball1.width + ball1.speedX); // offset to fix collision issue
            bricks.splice(i, 1); // delete block from array
            break;
        }
        
        if(brickCollider.CheckCollision(ballCollider2))
        {
            player2Hit = true;
            ballXBrick.play();
            ball2.dirX *= -1 ;
            ball2.x += ball2.dirX * (ball2.width + ball2.speedX);
            bricks.splice(i, 1);
            break;
        }
        
    } 
    for(var i = 0; i < bricks2.length; i++)
    {
        var brickCollider2 = RectangularCollider(bricks2[i].x - 5, bricks2[i].y - 5, bricks2[i].width + 10, bricks2[i].height + 10);
        if(brickCollider2.CheckCollision(ballCollider))
        {
            player1Hit = true;
            ballXBrick.play();
            ball1.dirX *= -1 ;
            ball1.x += ball1.dirX * (ball1.width + ball1.speedX);
            bricks2.splice(i, 1);
            break;
        }
        
        if(brickCollider2.CheckCollision(ballCollider2))
        {
            player2Hit = true;
            ballXBrick.play();
            ball2.dirX *= -1 ;
            ball2.x += ball2.dirX * (ball2.width + ball2.speedX);
            bricks2.splice(i, 1);
            break;
        }     
    }
    for(var i = 0; i < bricks3.length; i++)
    {   
        var brickCollider3 = RectangularCollider(bricks3[i].x - 5, bricks3[i].y - 5, bricks3[i].width + 10, bricks3[i].height + 10);
        if(brickCollider3.CheckCollision(ballCollider))
        {
            player1Hit = true;
            ballXBrick.play();
            ball1.dirX *= -1 ;
            ball1.x += ball1.dirX * (ball1.width + ball1.speedX);
            bricks3.splice(i, 1);
            break;
        }  
        
        if(brickCollider3.CheckCollision(ballCollider2))
        {
            player2Hit = true;
            ballXBrick.play();
            ball2.dirX *= -1 ;
            ball2.x += ball2.dirX * (ball2.width + ball2.speedX);
            bricks3.splice(i, 1);
            break;
        } 
    }
    for(var i = 0; i < bricks4.length; i++)
    {   
        var brickCollider4 = RectangularCollider(bricks4[i].x - 5, bricks4[i].y - 5, bricks4[i].width + 10, bricks4[i].height + 10);
        if(brickCollider4.CheckCollision(ballCollider))
        {
            player1Hit = true;
            ballXBrick.play();
            ball1.dirX *= -1 ;
            ball1.x += ball1.dirX * (ball1.width + ball1.speedX);
            bricks4.splice(i, 1);
            break;
        }    

        if(brickCollider4.CheckCollision(ballCollider2))
        {
            player2Hit = true;
            ballXBrick.play();
            ball2.dirX *= -1 ;
            ball2.x += ball2.dirX * (ball2.width + ball2.speedX);
            bricks4.splice(i, 1);
            break;
        }
    }
    for(var i = 0; i < bricks5.length; i++)
    {    
        var brickCollider5 = RectangularCollider(bricks5[i].x - 5, bricks5[i].y - 5, bricks5[i].width + 10, bricks5[i].height + 10);
        if(brickCollider5.CheckCollision(ballCollider))
        {
            player1Hit = true;
            ballXBrick.play();
            ball1.dirX *= -1 ;
            ball1.x += ball1.dirX * (ball1.width + ball1.speedX) ;
            bricks5.splice(i, 1);
            break;
        }

        if(brickCollider5.CheckCollision(ballCollider2))
        {
            player2Hit = true;
            ballXBrick.play();
            ball2.dirX *= -1 ;
            ball2.x += ball2.dirX * (ball2.width + ball2.speedX);
            bricks5.splice(i, 1);
            break;
        }
    }
    for(var i = 0; i < bricks6.length; i++)
    {
        var brickCollider6 = RectangularCollider(bricks6[i].x - 5, bricks6[i].y - 5, bricks6[i].width + 10, bricks6[i].height + 10);
        if(brickCollider6.CheckCollision(ballCollider))
        {
            player1Hit = true;
            ballXBrick.play();
            ball1.dirX *= -1 ;
            ball1.x += ball1.dirX * (ball1.width + ball1.speedX);
            bricks6.splice(i, 1);
            break;
        }

        if(brickCollider6.CheckCollision(ballCollider2))
        {
            player2Hit = true;
            ballXBrick.play();
            ball2.dirX *= -1 ;
            ball2.x += ball2.dirX * (ball2.width + ball2.speedX);
            bricks6.splice(i, 1);
            break;
        }
    }  
}


var Initialise = function()
{
    //makes sure that when the bricks break and the game resets, the collisions for the bricks and the bricks drawing reset properly
    //it's also only run once when initialised = false, so it doesn't break
    bricks = [];
    bricks2 = [];
    bricks3 = [];
    bricks4 = [];
    bricks5 = [];
    bricks6 = [];

    var numberOfBricksYouWant = 8;
    for(var i=0; i<numberOfBricksYouWant; i++)
    {
        bricks.push(spawnBrick(screenWidth/2, 110 * i + 12, "graphics/Red.png"));
        bricks2.push(spawnBrick(screenWidth/2 - 35, 110 * i + 12, "graphics/Red.png"));
        bricks3.push(spawnBrick(screenWidth/2 - 70, 110 * i + 12, "graphics/Blue.png"));
        bricks4.push(spawnBrick(screenWidth/2 + 35, 110 * i + 12, "graphics/Blue.png"));
        bricks5.push(spawnBrick(screenWidth/2 + 70, 110 * i + 12, "graphics/Yellow.png"));
        bricks6.push(spawnBrick(screenWidth/2 - 105, 110 * i + 12, "graphics/Yellow.png"));
    }
}