//player movement
var isWPressed = false;
var isSPressed = false;
var isUpPressed = false;
var isDownPressed = false;

//score image
var score1 =document.createElement('img');

//score image
score1.src="graphics/1.png";
var score2 =document.createElement('img');
score2.src="graphics/2.png";
var score3 =document.createElement('img');
score3.src="graphics/3.png";
var score4 =document.createElement('img');
score4.src="graphics/4.png";
var score5 =document.createElement('img');
score5.src="graphics/5.png";

//PlayerScores
var player1Hit = false;
var player1LivesScore = 0;

var player2Hit = false;
var player2LivesScore = 0;

var px = px;
var py = py;


var spawnPlayer = function(playerX, playerY, src, pName)
{
    //creating player object
    var player = 
    {
        x:playerX,
        y:playerY,
        playerLives: 3,
        width:20,
        height:100,
        PlayerSpeed: 10,
        MINPLAYERLIVES: 0,
        MAXPLAYERLIVES: 5,
        name:pName,
        score:0,
        scoreX:px,
        scoreY:py
    }
    player.image = document.createElement("img");
    player.image.src = src;
    
    //setting up function to draw player
    player.draw = function(){
        context.drawImage(player.image, player.x, player.y, player.width, player.height);
    }

    return player;
}

//drawing the players lives in game state (the massive numbers on screen)
var PlayerLives = function()
{
    //player 1
    if(player1.playerLives==3)
    {
        context.drawImage(score3,60,0)
    }
    else if(player1.playerLives==2)
    {
        context.drawImage(score2,60,0)
    }
    else if(player1.playerLives==1)
    {
        context.drawImage(score1,60,0)
    }
    else if(player1.playerLives==4)
    {
        context.drawImage(score4,60,0)
    }
    else if(player1.playerLives==5)
    {
        context.drawImage(score5,60,0)
    }
    //preventing the player lives from going above 5
    if(player1.playerLives==6)
    {
        player1.playerLives = 5;
    }
    
    //player 2
    if(player2.playerLives==3)
    {
        context.drawImage(score3,740,0)
    }
    else if(player2.playerLives==2)
    {
        context.drawImage(score2,740,0)
    }
    else if(player2.playerLives==1)
    {
        context.drawImage(score1,740,0)
    }
    else if(player2.playerLives==4)
    {
        context.drawImage(score4,740,0)
    }
    else if(player2.playerLives==5)
    {
        context.drawImage(score5,740,0)
    }
    //preventing the player lives from going above 5
    if(player2.playerLives==6)
    {
        player2.playerLives = 5;
    }
    
}

//detecting input from the keyboard
var PlayerInput = function()
{
    //Keyboard
    //moves player and sets 'isWPressed' to true to help in Ball collision/movement in ball.js
    if(keyboard.isKeyDown(keyboard.KEY_W))
    {
        player1.y -= player1.PlayerSpeed;
        isWPressed = true;
    }
    if(keyboard.isKeyDown(keyboard.KEY_S))
    {
        player1.y += player1.PlayerSpeed;
        isSPressed = true;
    }
    if(keyboard.isKeyDown(keyboard.KEY_UP))
    {
        player2.y -= player1.PlayerSpeed;
        isUPPressed = true;
    }
    if(keyboard.isKeyDown(keyboard.KEY_DOWN))
    {
        player2.y += player1.PlayerSpeed;
        isDOWNPressed = true;
    }
}

//preventing the player from going off the screen
var PlayerCollisions = function()
{
    //P1
    if(player1.y < 12)
    {
        player1.y = 12;
    } 
	else if((player1.y + player1.height) > screenHeight - 12)
    {
        player1.y = screenHeight - player1.height - 12;
    }
    
    //P2
    if(player2.y < 12)
    {
        player2.y = 12;
    } 
	else if((player2.y + player1.height) > screenHeight - 12)
    {
        player2.y = screenHeight - player1.height - 12;
    }
}

//add to the player's score
var playerScore = function()
{
    if (player1Hit == true)
    {
        player1.score ++;
        player1LivesScore++;
        player1Hit = false;
        //if the score gets to 12 add a live and then reset the livescore
        if (player1LivesScore == 12)
        {  
            player1.playerLives ++;
            player1LivesScore = 0;
        }
    }
    if (player2Hit == true)
    {
        player2.score ++;
        player2LivesScore ++;
        player2Hit = false;
        //if the score gets to 12 add a live and then reset the livescore
        if (player2LivesScore == 12)
        {  
            player2.playerLives ++;
            player2LivesScore = 0;
        }
    }
}
