var spawnBall = function(ballPosX, ballPosY, ballDirX, ballDirY, ballSpeedX, ballSpeedY, src)
{
    var ball =
    {
        x:ballPosX,
        y:ballPosY,
        width:20,
        height:20,
        dirY:ballDirY,
        dirX:ballDirX,
        speedX:ballSpeedX,
        speedY:ballSpeedY,
        MAXBALLSPEED:5,
    }
    ball.image = document.createElement("img");
    ball.image.src = src;

    ball.draw = function(){
        context.drawImage(ball.image, ball.x, ball.y, ball.width, ball.height);
    }

    ball.move = function(){
        ball.x += ball.speedX * ball.dirX;
        ball.y += ball.speedY * ball.dirY;
    }

    return ball;
}

var BallCollisions = function()
{
    // Left wall
    if (ball1.x < 0) //checks if ball1 hits left wall
	{
        player1.playerLives --; //remove player 1 life
        player1.score -= 2; //take 2 score away from player 1, which then translates to -2000 points
        ResetLevel(); //run reset level
        if(player1.playerLives <= 0) //checks if player1's lives are less than 0 
        {
            gameOver.play(); //plays sound
            gameState = STATE_GAME_OVER;

        }
    }

    if (ball2.x < 0) //checks if ball2 hits left wall
	{
        player1.playerLives --;
        player1.score -= 2;
        ResetLevel();
        if(player1.playerLives <= 0)
        {
            gameOver.play();
            gameState = STATE_GAME_OVER;

        }
    }
    
    // Right wall
    if ((ball1.x + ball1.width) > screenWidth) //checks if ball1 hits right wall
	{
        player2.playerLives --;
        player2.score -= 2;
        ResetLevel(); 
        if(player2.playerLives <= 0)
        {
            gameOver.play();
            gameState = STATE_GAME_OVER;

        } 
    }
   
    if ((ball2.x + ball2.width) > screenWidth) //checks if ball2 hits right wall
	{
        player2.playerLives --;
        player2.score -= 2;

        ResetLevel(); 
        if(player2.playerLives <= 0)
        {
            gameOver.play();
            gameState = STATE_GAME_OVER;

        } 
    }

    //Bottom wall
    if ((ball1.y + ball1.height) > screenHeight - 12) //checks if ball1 hits Bottom wall, if so it just moves the ball away from the wall
    {
        ball1.y = screenHeight - ball1.height - 12;
        ball1.dirY *= -1;
    }
    
    if ((ball2.y + ball2.height) > screenHeight - 12) //checks if ball2 hits Bottom wall
    {
        ball2.y = screenHeight - ball2.height - 12;
        ball2.dirY *= -1;
    }

    //Top wall
    if((ball1.y < 12)) //checks if ball1 hits Top wall, if so it just moves the ball away from the wall
    {
        ball1.y = 12;
        ball1.dirY *= -1;
    }

    if((ball2.y < 12)) //checks if ball2 hits Top wall
    {
        ball2.y = 12;
        ball2.dirY *= -1;
    }

    //variables for players x ball collisions
    var p1Collider = RectangularCollider(player1.x, player1.y, player1.width, player1.height);
    var p2Collider = RectangularCollider(player2.x, player2.y, player2.width, player2.height);
    var ballCollider = RectangularCollider(ball1.x, ball1.y, ball1.width, ball1.height);
    var ballCollider2 = RectangularCollider(ball2.x, ball2.y, ball1.width, ball1.height);

    //Ball 1 and 2 with player 1
    if(p1Collider.CheckCollision(ballCollider)) //ball1
    {
        ballXPaddle.play();
        ball1.dirX *= -1;
        if (isWPressed) 
		{
            ball1.dirY += -1;
        }
        if (isSPressed) 
		{
            ball1.dirY += 1;
        }
        if (ball1.speedX < ball1.MAXBALLSPEED) 
		{
            ball1.speedX += 0.75;
        }
    }

    if(p1Collider.CheckCollision(ballCollider2)) //ball2
    {
        ballXPaddle.play(); //play sound
        ball2.dirX *= -1; //move ball opposite direction
        //these next couple of if statements detects if certain keys are being pressed to move the ball in a specific direction
        if (isWPressed) 
		{
            ball2.dirY += -1;
        }
        if (isSPressed) 
		{
            ball2.dirY += 1;
        }
        //This if statement increments ball speed as long as its less than max ball speed
        if (ball2.speedX < ball1.MAXBALLSPEED) 
		{
            ball2.speedX += 0.75;
        }
    }
    //Ball 1 and 2 with player 2
    //same as above just with player 2
    if(p2Collider.CheckCollision(ballCollider))
    {
        ballXPaddle.play();
        ball1.dirX *= -1;
        if (isUpPressed) 
        {
            ball1.dirY += -1;
        }
        if (isDownPressed) 
        {
            ball1.dirY += 1;
        }
        if (ball1.speedX < ball1.MAXBALLSPEED) 
		{
            ball1.speedX += 0.75;
        }
    }

    if(p2Collider.CheckCollision(ballCollider2))
    {
        ballXPaddle.play();
        ball2.dirX *= -1;
        if (isUpPressed) 
        {
            ball2.dirY += -1;
        }
        if (isDownPressed) 
        {
            ball2.dirY += 1;
        }
        if (ball2.speedX < ball1.MAXBALLSPEED) 
		{
            ball2.speedX += 0.75;
        }
    }
}