//General
var canvas = document.getElementById("gameCanvas");
var context = canvas.getContext("2d");

var screenWidth = canvas.width;
var screenHeight = canvas.height;

var backGround = document.createElement("img");
backGround.src = "graphics/GameScreen.png";

var GOB = document.createElement("img");
GOB.src = "graphics/Player1Win.png"
var GOB2 = document.createElement("img");
GOB2.src = "graphics/Player2Win.png"

var GameScreen = document.createElement("img");
GameScreen.src = "graphics/game.png";

//Balls
var ball1 = spawnBall(screenWidth / 2 - 135, screenHeight / 2, -1, (-2 * Math.random()) + 1, 3, 3, "graphics/Ball1.png");
var ball2 = spawnBall(screenWidth / 2 + 135, screenHeight / 2, 1, (2 * Math.random()) - 1, 3, 3, "graphics/Ball2.png");
//Players
var player1 = spawnPlayer(12, screenHeight/2 - 50, "graphics/Player1.png","Player 1")
var player2 = spawnPlayer(screenWidth - 32, screenHeight/2 - 50, "graphics/Player2.png","Player 2")

//Bricks
var bricks = [];
var bricks2 = [];
var bricks3 = [];
var bricks4 = [];
var bricks5 = [];
var bricks6 = [];

//gamestate
var STATE_MENU = 0;
var STATE_GAME = 1;
var STATE_GAME_OVER = 2;
var gameState = STATE_MENU

//initialised
var initialised = false;

//Menu music playing
var musicPlaying = false;

//music
MusicLoad();

function moveBall() 
{
    //move the ball    
    ball1.move();
    ball2.move();
}

function ResetLevel()
{ 
    //reset the level to its original state 
    Initialise();
    ball1.x = screenWidth / 2 - 135;
    ball1.y = screenHeight / 2;
    ball2.x = screenWidth / 2 + 135;
    ball2.y = screenHeight / 2;

    ball1.dirX = -1;
    ball1.dirY = (-2 * Math.random()) + 1;
    ball2.dirX = 1;
    ball2.dirY = (2 * Math.random()) - 1;

    ball1.speedX = 3;
    ball1.speedY = 3;
    ball2.speedX = 3;
    ball2.speedY = 3;

    player1.y = screenHeight/2 - 50;
    player2.y = screenHeight/2 - 50;
    player1.PlayerSpeed = 10;
}

function UpdateMenu()
{
    //check if the space button is pressed to then initiate the game
    if(keyboard.isKeyDown(keyboard.KEY_SPACE))
    {
        gameMusic.play();
        gameState = STATE_GAME;
        player1.playerLives = 3;
        player2.playerLives = 3;
        player1Score = 0;
        player2Score = 0;
    }
}

function DrawMenu()
{
    //draw the menu image
    context.drawImage (backGround,0, 0, screenWidth,screenHeight);
}

function UpdateGame()
{
    //run the functions for the game
    moveBall();
    PlayerInput();
    PlayerCollisions();
    playerScore();
    BallCollisions();
    BrickCollisions();

    if (initialised==false)
    {
        initialised = true;
        Initialise();
    }
}

function DrawGame()
{
    //background
    context.drawImage (GameScreen,0, 0,screenWidth,screenHeight+25);
    PlayerLives();
    
    //Ball
    ball1.draw();
    ball2.draw();
    
    //Player
    player1.draw();
    player2.draw();

    //Draw all the bricks
    for(var i=0; i<bricks.length; i++)
    {
        context.drawImage(bricks[i].image, bricks[i].x, bricks[i].y);
    }
     
    for(var i=0; i<bricks2.length; i++)
    {
        context.drawImage(bricks2[i].image, bricks2[i].x, bricks2[i].y);
    }
     
    for(var i=0; i<bricks3.length; i++)
    {
        context.drawImage(bricks3[i].image, bricks3[i].x, bricks3[i].y);
    }
 
    for(var i=0; i<bricks4.length; i++)
    {
        context.drawImage(bricks4[i].image, bricks4[i].x, bricks4[i].y);
    }
 
    for(var i=0; i<bricks5.length; i++)
    {
        context.drawImage(bricks5[i].image, bricks5[i].x, bricks5[i].y);
    }
 
    for(var i=0; i<bricks6.length; i++)
    {
        context.drawImage(bricks6[i].image, bricks6[i].x, bricks6[i].y);
    }

}

function UpdateGameOver()
{
    //check if the enter button is pressed and check if the space button is pressed to change to another game state
    if(keyboard.isKeyDown(keyboard.KEY_ENTER))
    {
        gameState = STATE_MENU;
    }
    else if(keyboard.isKeyDown(keyboard.KEY_SPACE))
    {
        gameState = STATE_MENU;
    }
}

function DrawGameOver()
{
    //draw the game over screen depending on which player wins
    if(player1.playerLives == 0)
    {
        context.drawImage (GOB2,0,0,screenWidth,screenHeight);
    }
    if(player2.playerLives == 0)
    {
        context.drawImage (GOB,0,0,screenWidth,screenHeight);
    }
    DrawScore(player1, player2);

}

function DrawScore(pPlayer, pPlayer2)
{
    //draw the score for each player on the game over screen
    context.drawImage (GOB2,0,0,screenWidth,screenHeight);
        context.font = "24px Arial";
        context.fillStyle = "rgb(46,179,9)";
        context.fillText(pPlayer.name + " score: " + (pPlayer.score*1000), screenWidth/4, screenHeight/2 + 150);
        context.fillStyle ="rgb(168,2,250)";
        context.fillText(pPlayer2.name + " score: " + (pPlayer2.score*1000), screenWidth/2 + 150,screenHeight/2 + 150);
}

function Loop()
{
    //load different game states
    switch(gameState)
    {
        //run the menu state
        case STATE_MENU:
        UpdateMenu();
        DrawMenu();
        break;
        //run the game state
        case STATE_GAME:
        UpdateGame();
        DrawGame();
        break;
        //run the game over state
        case STATE_GAME_OVER:
        UpdateGameOver();
        DrawGameOver();
        gameMusic.stop();
        break;
    }
    requestAnimationFrame(Loop);
}

Loop();