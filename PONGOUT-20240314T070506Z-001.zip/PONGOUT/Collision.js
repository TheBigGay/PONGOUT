RectCircleCollision = function(rect, circle){

	//find distance apart
	var distX = Math.abs(circle.x - rect.x-rect.width/2);
    var distY = Math.abs(circle.y - rect.y-rect.height/2);

    //if the distance apart is greater than half the circle + half the rect, they are too far apart
    if (distX > (rect.width/2 + circle.radius)) { return false; }
    if (distY > (rect.height/2 + circle.radius)) { return false; }

    //if the distance is less than half the rect, they are definitely colliding
    if (distX <= (rect.width/2)) { return true; } 
    if (distY <= (rect.height/2)) { return true; }

    //use pythagoras to compare the distance between circle and rect centres
    var dx=distX-rect.width/2;
    var dy=distY-rect.height/2;

    //return result
    return (dx*dx+dy*dy<=(circle.radius*circle.radius));
}

RectRectCollision = function(rect1, rect2){

	//return whether this rectangle is intersecting another rectangle
	return 	rect1.x <= rect2.x + rect2.width 	&&
			rect2.x <= rect1.x + rect1.width	&&
			rect1.y <= rect2.y + rect2.height 	&&
			rect2.y <= rect1.y + rect1.height;
}

CircleCircleCollision = function(circle1, circle2){

	//x distance
	var distX = circle1.x - circle2.x;

	//y distance
	var distY = circle1.y - circle2.y;

	//get distance between collisions
	var distance = Math.abs(distX + distY); 
	
	//check distance
	return distance < circle1.radius + circle2.radius;
}

//RECTANGULAR COLLISION
function RectangularCollider(pX, pY, pWidth, pHeight){

	var self ={
		type:"Rectangle",
		x:pX,
		y:pY,
		width:pWidth,
		height:pHeight,
	}

	self.CheckCollision = function(pOther){

		if(pOther.type === "Rectangle"){
			//do rectangle v rectangle check
			return RectRectCollision(self, pOther);
	
		}else if(pOther.type === "Circle"){
			//do rectangle v circle check
			return RectCircleCollision(self, pOther);
	
		}else{
			//throw error if we somehow end up with an invalid collider type
			throw new Error("Invalid collider type");
		}
	}

	return self;
}

//CIRCULAR COLLISION
function CircleCollider(pX, pY, pRadius){

	var self ={
		type:"Circle",
		x:pX,
		y:pY,
		radius:pRadius,
	}

	self.CheckCollision = function(pOther){
	
		if(pOther.type === "Rectangle"){
			//do circle v rectangle check
			return RectCircleCollision(pOther, self);
	
		}else if(pOther.type === "Circle"){
			//do circle v circle check
			return CircleCircleCollision(self, pOther);
	
		}else{
			//throw error if we somehow end up with an invalid collider type
			throw new Error("Invalid collider type");
		}
	}

	return self;
}